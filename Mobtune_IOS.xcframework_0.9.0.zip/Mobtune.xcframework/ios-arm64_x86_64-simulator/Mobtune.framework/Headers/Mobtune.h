//
//  Mobtune.h
//  Mobtune
//
//  Created by DoHyoung Kim on 2021/06/17.
//

#import <Foundation/Foundation.h>

//! Project version number for Mobtune.
FOUNDATION_EXPORT double MobtuneVersionNumber;

//! Project version string for Mobtune.
FOUNDATION_EXPORT const unsigned char MobtuneVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Mobtune/PublicHeader.h>


